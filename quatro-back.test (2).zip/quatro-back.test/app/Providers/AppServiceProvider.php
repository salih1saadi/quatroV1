<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\Validator;
use Illuminate\Database\Eloquent\Relations\Relation;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //
    }

    public function boot()
    {
        Relation::morphMap([
            'Product' => 'App\Models\Product',
            'Customer' => 'App\Models\Customer',
            'Employee' => 'App\Models\Employee',
            'Store' => 'App\Models\Store',
            'Order' => 'App\Models\Order',
            'Hub' => 'App\Models\Hub',
            'Airport' => 'App\Models\Airport',
            'Delivery' => 'App\Models\Delivery',
        ]);

    $this->initCustomValidate();
    }

    public function initCustomValidate()
    {
        Validator::extend('phone', function ($attribute, $value, $parameters, $validator) {
            // return preg_match('(05)[0-9]{9}/', $value);
            return preg_match('/(05)[0-9]{1}-[0-9]{7}/', $value) || preg_match('/(05)[0-9]{1}[0-9]{7}/', $value);
        });

        Validator::extend('multipleFieldUnique', function ($attribute, $value, $parameters, $validator) {
        });

        Validator::extend('id_valid', function ($attribute, $value, $parameters, $validator) {
            if (! ctype_digit($value)) {
                return false;
            }
            if (strlen($value) < 9) {
                $value = str_pad($value, 9, '0', STR_PAD_LEFT);
            }

            if ($value == '000000000') {
                return false;
            }

            for ($i = 0; $i < 9; $i++) {
                if ($i % 2 != 0) {
                    $c = $value[$i] * 2;

                    if ($c > 9) {
                        $value[$i] = ($c % 10) + 1;
                    } else {
                        $value[$i] = $c;
                    }
                }
            }
            if ((array_sum(str_split($value))) % 10 > 0) {
                return false;
            }

            return true;
        });

        Relation::morphMap([   
        ]);
    }
}
