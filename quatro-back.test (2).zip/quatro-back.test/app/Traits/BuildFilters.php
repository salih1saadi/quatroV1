<?php

namespace App\Traits;

use Illuminate\Support\Str;

trait BuildFilters
{
    /**
     * Scope a query to only include active users.
     *
     * @param  \Illuminate\Database\Eloquent\Builder  $query
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeSetFilters($query, $filters)
    {
        foreach ($filters as $filter) {
            $af = json_decode($filter, 1);
            if (gettype($af['value']) == 'array') {
                $af['value'] = $af['value']['id'];
            }

            $operator = isset($af['operator']['operator']) ? $af['operator']['operator'] : $af['operator']['value'] ?? $af['operator'];
            if(!empty($af['field']) && !empty($af['field']['typeData']) && $af['field']['typeData'] == 'inModel'){
                $operator = 'inModel';
            }

            if (gettype($af['field']) == 'array') {
                // if(strpos($af['field']['value'],'custom') !== false ){
                if (Str::contains($af['field']['value'], 'custom') && ! Str::contains($af['field']['value'], 'customer')) {
                    $af['field'] = $af['field']['column'] ?? $af['operator'];
                } else {
                    $af['field'] = $af['field']['value'] ?? $af['operator'];
                }
            }

            switch ($operator) {
                case 'contains':
                    $query = $query->where($af['field'], 'like', "%{$af['value']}%");
                    break;

                case 'start':
                    $val = "%{$af['value']}";

                    $containsHebrew = preg_match("/\p{Hebrew}/u", $af['value']);
                    $containsNumeric = preg_match("/^\d+$/", $af['value']);

                    if ($containsHebrew || $containsNumeric) {// ONLY HE
                        $val = "{$af['value']}%";
                    }
                    $query = $query->where($af['field'], 'like', $val);
                    break;

                case 'end':

                    $val = "{$af['value']}%";

                    $containsHebrew = preg_match("/\p{Hebrew}/u", $af['value']);
                    $containsNumeric = preg_match("/^\d+$/", $af['value']);

                    if ($containsHebrew || $containsNumeric) {// ONLY HE
                        $val = "%{$af['value']}";
                    }
                    $query = $query->where($af['field'], 'like', $val);
                    break;

                case '=':
                    $query = $query->where($af['field'], 'like', "{$af['value']}");
                    break;

                case '>':
                    $query = $query->where($af['field'], '>', $af['value']);
                    break;

                case '>=':
                    break;

                case '<':
                    $query = $query->where($af['field'], '<', $af['value']);
                    break;

                case '<=':
                    $query = $query->where($af['field'], '<=', $af['value']);
                    break;

                case 'has':
                    $query = $query->has($af['field'], $af['operator']['value'], $af['value']);
                    break;

                case 'inModel':
                    $query = $this->getQuery($query, $af['value'], $af['field']);
                    break;

                default:
                    break;
            }
        }

        return $query;
    }
}
