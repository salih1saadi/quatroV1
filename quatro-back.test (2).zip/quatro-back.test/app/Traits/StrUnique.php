<?php

namespace App\Traits;

use App\Models\OrderLine;


trait StrUnique
{
    protected static $uniqueColDefault = 'unique_str';
    protected static $useUniqueColDefault = true;

    protected static $currentData = [];

    public function getCurrentData()
    {
        self::$currentData['useUniqueCol'] = self::$useUniqueCol ??  self::$useUniqueColDefault;
        self::$currentData['uniqueCol'] = self::$uniqueCol ??  self::$uniqueColDefault;

        return self::$currentData;
    }

    protected static function bootStrUnique()
    {
        // parent::boot();

        static::saving(function ($model){
            self::onUpdate($model);
        });

        // static::updating(function ($model){
        //     self::onUpdate($model);
        // });

        self::$currentData['useUniqueCol'] = self::$useUniqueCol ??  self::$useUniqueColDefault;
        self::$currentData['uniqueCol'] = self::$uniqueCol ??  self::$uniqueColDefault;
        // dd(2);

        // dd(static::$recordEvents);

        if(self::$currentData['useUniqueCol']) {
        // if(isExists(self::$useUniqueCol) || (!isExists(self::$useUniqueCol) && self::$useUniqueColDefault)) {
            static::creating(function ($model){
                self::onCreate($model);
            });

            static::updated(function ($model){
                self::onUpdate($model);
            });

            static::updating(function ($model){
                self::onUpdate($model);
            });

            static::deleted(function ($model){
                dd('12');
                self::onDelete($model);
            });

            // static::forceDeleted(function ($model){
            //     self::onDelete1($model);
            // });
        }
    }


    private static function onCreate($model)
    {
        // dd('create');
        $str = self::buildStrUnique($model);
        $model[self::$currentData['uniqueCol']] =  $str;
    }

    private static function onUpdate($model)
    {
        $str = self::buildStrUnique($model);
        $model->deleted_at =  $model->deleted_at ?? null;
        $model[self::$currentData['uniqueCol']] =  $str;
        dd('121212' ,$model);
        // $model->$uniqueCol =  hash('sha256', collect($str)->toJson());
    }

    private static function onDelete($model)
    {
        dd('trashed' ,$model);
        $str = self::buildStrUnique($model);
        $model[self::$currentData['uniqueCol']] =  $str;
        $model->save();
    }

    private static function onDelete1($model)
    {
        dd('forceDeleted' ,$model);
        $str = self::buildStrUnique($model);
        $model[self::$currentData['uniqueCol']] =  $str;
        $model->save();
    }

    private function buildStrUnique($model)
    {
        $strValue = collect(self::$colsInUnique)->map(function ($col) use($model){
            return $model[$col] ?? null; //לתמוך במידה והשדה הוא ריק  - יש צורך להכניס את הערף הדפולטיבי
        })->values()->all();

        $strValue = implode(',', $strValue);
        return hash('sha256', collect($strValue)->toJson());
    }
    

    public static function rlUpsert($lines, $colsUnique, $colsToUpdate)
    {
        $lines = self::buildStrUniqueLines($lines);
        return static::upsert(self::buildStrUniqueLines($lines), $colsUnique, $colsToUpdate);
    }

    public function buildStrUniqueLines($lines)
    {
        self::$currentData = self::getCurrentData();
        $data = collect($lines)->map(function($line)
        {
            $line[self::$currentData['uniqueCol']] = self::buildStrUnique($line);
            return $line;
        })->values()->all();

        return $data;
        # code...
    }

    public function delete()
    {
        dd('delete');
        // $order->lines()->delete();
        // $order->lines()->onlyTrashed()->update([
        //     'de'
        // ]);
    }


 
}
