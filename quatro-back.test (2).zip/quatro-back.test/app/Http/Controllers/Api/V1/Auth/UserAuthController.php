<?php

namespace App\Http\Controllers\Api\V1\Auth;

use App\Models\User;
use App\Models\UserAddress;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use App\Http\Requests\UserStoreRequest;
use App\Notifications\WelcomeEmailNotification;

class UserAuthController extends Controller
{

    public function login(Request $request)
    {

        $data = $request->validate([
            'email' => ['required'],
            'password' => ['required']
        ]);

        if (!Auth::attempt($data)) {
            return response()->json([
                'status' => -1,
                'errors' => 'failed',
                'message' => 'Incorrect Details. Please try again',
            ], 422);
        }

        $token = Auth::user()->createToken('API Token')->accessToken;
        $user = Auth::user();

        return response()->json([
            'status' => '200',
            'user' => $user,
            'authorisation' => [
                'token' => $token,
                'type' => 'bearer',
            ]
        ]);

    }


    public function register(UserStoreRequest $request)
    {

        $validated = $request->validated();

        $user = User::where('email', $validated['formData']['email'])->first();

        if ($user) {
            return response()->json([
                'status' => -1,
                'errors' => 'failed',
                'message' => 'Email is already exist',
            ], 422);
        }

        $user = User::create([
            'first_name' => $validated['formData']['first_name'],
            'last_name' => $validated['formData']['last_name'],
            'phone' => $validated['formData']['phone'],
            'email' => $validated['formData']['email'],
            'password' => bcrypt($validated['formData']['password']),
        ]);

        if ($user) {

            UserAddress::create([
                'user_id' => $user->id,
                'street' => $validated['formData']['street'],
                'city' => $validated['formData']['city'],
                'apartment' => $validated['formData']['apartment'],
                'entrance' => $validated['formData']['entrance'] ?? '',
                'building_code' => $validated['formData']['building_code'] ?? '',
            ]);
        }

        $user->notify(new WelcomeEmailNotification($user));

        return response()->json([
            'status' => '200',
            'message' => 'User created successfully',
            'user' => $user,
        ]);
    }

    public function getUser()
    {
        $user =  Auth::guard('api')->user();
       
        return response()->json([
            'status' => '200',
            'user' => $user,
        ]);
    }

}
