<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class UserStoreRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'formData.email' => [
                'required',
                'string',
                'email', 'max:255',
            ],
            'formData.password' => [
                'required',
                'min:8',
                'confirmed',
            ],
            'formData.first_name' => ['required', 'string', 'max:255'],
            'formData.last_name' => ['required', 'string', 'max:255'],
            'formData.phone' => ['required', 'string', 'max:11'],
            'formData.street' => ['required', 'string', 'max:255'],
            'formData.is_accept_advertisment' => ['nullable', 'boolean'],
            'formData.city' => ['required', 'string', 'max:255'],
            'formData.apartment' => ['required', 'integer', 'max:255'],
            'formData.entrance' => ['nullable', 'string', 'max:255'],
            'formData.building_code' => ['nullable', 'string', 'max:255'],



        ];
    }
    public function messages()
    {
        return [
            'email.required' => 'Email is required',
            'email.email' => 'Email is true',
            // 'password.required'=> 'Password is required'

        ];
    }
}
