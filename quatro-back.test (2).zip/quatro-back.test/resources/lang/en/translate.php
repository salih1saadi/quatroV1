<?php

return [
    'total_price' => 'total_price',
    'service' => 'service',
    'customer_name' => 'customer name',
    'total' => 'Total',
];