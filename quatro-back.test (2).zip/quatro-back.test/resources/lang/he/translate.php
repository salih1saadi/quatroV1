<?php

return [
    'total_price' => 'מחיר סופי',
    'service' => 'סוג שירות',
    'customer_name' => 'שם הלקוח',
    'total' => 'סך הכל',
];