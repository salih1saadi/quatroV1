module.exports = shipit => {
    require("shipit-deploy")(shipit);

    shipit.initConfig({
        default: {
            workspace: "temp",
            deployTo: "moneyt/api",
            repositoryUrl: "git@bitbucket.org:app-rl/cando-back.git",
            ignores: [
                "/node_modules",
                "/public/hot",
                "/public/storage",
                "/storage/*.key",
                "/vendor",
                "/deploy",
                ".phpunit.result.cache",
                "Homestead.json",
                "Homestead.yaml",
                "npm-debug.log",
                "yarn-error.log",
                "shipitfile.js",
                ".env"
            ],
            keepReleases: 5,
            keepWorkspace: false,
            deleteOnRollback: false
        },
        stage: {
            servers: "app@3.120.103.117",
            branch: process.env.SHIPIT_BRANCH
        }
    });

    shipit.on("updated", async () => {
        await shipit.start([
            "genenv",
            "install",
            "storageLink",
            "migrateAndSeed",
            "passportInstall",
            "artisanOptimze",
            // "npmInstall",
            // "npmRunProd"
            // 'configCache',
            // "artisanDown"
        ]);
    });

    shipit.blTask("genenv", async () => {
        let result;
        try {
            result = await shipit.remote(
                `genenv /moneyt/api > /home/app/${shipit.releasePath}/.env`
            );
        } catch (error) {
            throw new Error("cannot gen env");
        }

        return result;
    });

    shipit.blTask("install", async () => {
        let result;
        try {
            result = await shipit.remote(
                `cd ${shipit.releasePath} && composer install`
            );
        } catch (error) {
            throw new Error("cannot complete 'composer install'");
        }

        return result;
    });

    shipit.blTask("storageLink", async () => {
        let result;
        try {
            result = await shipit.remote(
                `cd /home/app/${shipit.releasePath} && rm -rf public/storage && php artisan storage:link`
            );
        } catch (error) {
            throw new Error("cannot complete 'storage link'");
        }

        return result;
    });

    shipit.blTask("configCache", async () => {
        let result;
        try {
            result = await shipit.remote(
                `cd ${shipit.releasePath} && php artisan config:cache`
            );
        } catch (error) {
            throw new Error("cannot create config:cache");
        }

        return result;
    });

    shipit.blTask("migrateAndSeed", async () => {
        let result;
        try {
            result = await shipit.remote(
                `cd ${shipit.releasePath} && php artisan migrate:refresh --seed`
            );
        } catch (error) {
            throw new Error("cannot run migrate");
        }

        return result;
    });

    shipit.blTask("artisanOptimze", async () => {
        let result;
        try {
            result = await shipit.remote(
                `cd ${shipit.releasePath} && php artisan optimize`
            );
        } catch (error) {
            throw new Error("cannot create optimize");
        }

        return result;
    });

    shipit.blTask("artisanDown", async () => {
        let result;
        try {
            result = await shipit.remote(
                `cd ${shipit.releasePath} && php artisan down`
            );
        } catch (error) {
            throw new Error("cannot artisan down");
        }

        return result;
    });

    shipit.blTask("passportInstall", async () => {
        let result;
        try {
            result = await shipit.remote(
                `cd ${shipit.releasePath} && php artisan passport:install`
            );
        } catch (error) {
            throw new Error("cannot passport:install");
        }

        return result;
    });

    shipit.blTask("artisanCommands", async () => {
        let result;

        try {
            if (program.migrate || false) {
                result = await shipit.remote(
                    `cd ${shipit.releasePath} && php artisan migrate --force`
                );
            }
        } catch (error) {
            throw new Error("cannot complete 'artisan commands'");
        }

        return result;
    });

    shipit.blTask("npmInstall", async () => {
        let result;
        try {
            result = await shipit.remote(
                `cd ${shipit.releasePath} && npm install`
            );
        } catch (error) {
            throw new Error("cannot npm install");
        }

        return result;
    });

    shipit.blTask("npmRunProd", async () => {
        let result;
        try {
            result = await shipit.remote(
                `cd ${shipit.releasePath} && npm run prod`
            );
        } catch (error) {
            throw new Error("cannot npm run prod");
        }

        return result;
    });
};