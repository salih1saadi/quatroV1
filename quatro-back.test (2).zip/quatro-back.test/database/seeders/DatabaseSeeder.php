<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        $this->call([
            ManagementSeeder::class,
            ApplicationSeeder::class,
            UserSeeder::class,
            NotificationSeeder::class,
            ProductSeeder::class,
            OrderSeeder::class,
            MediaSeeder::class,
        ]);
    }
}
