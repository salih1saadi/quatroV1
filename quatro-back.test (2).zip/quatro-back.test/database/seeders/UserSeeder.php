<?php

namespace Database\Seeders;
use App\Models\Hub;
use App\Models\User;
use App\Models\Store;
use App\Models\Airport;
use App\Models\Customer;
use App\Models\Delivery;
use App\Models\Employee;
use App\Models\UserType;
use App\Models\Application;
use App\Models\UserUserType;
use Illuminate\Database\Seeder;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {



        
    }
}
